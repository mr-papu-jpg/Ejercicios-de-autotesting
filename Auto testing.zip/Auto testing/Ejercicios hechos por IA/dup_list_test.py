import unittest
import dup_list

class TestDuplicarLista(unittest.TestCase):
    def testmultiplicacioninvalida(self):
        with self.assertRaises(TypeError):
            duplicar_lista([1, 2, 3])
            
if __name__ == '__main__':
    unittest.main()            