import unittest
import division

class TestDividir(unittest.TestCase):
    def testdivisionpor_cero(self):
        with self.assertRaises(ZeroDivisionError):
            dividir(10, 0)
            
if __name__ == '__main__':
    unittest.main()            