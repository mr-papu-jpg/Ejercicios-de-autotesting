import unittest
import bus_diccionario

class TestBuscarValor(unittest.TestCase):
    def testclaveinexistente(self):
        datos = {"nombre": "Angel"}
        with self.assertRaises(KeyError):
            buscar_valor(datos, "edad")  # Clave no existe
            
if __name__ == '__main__':
    unittest.main()            