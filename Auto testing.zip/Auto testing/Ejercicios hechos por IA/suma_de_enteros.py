def sumar_elementos(a, b):
    return a + b