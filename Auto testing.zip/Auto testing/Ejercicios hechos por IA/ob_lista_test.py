import unittest
import ob_lista

class TestObtenerElemento(unittest.TestCase):
    def testindicefueraderango(self):
        datos = [1, 2, 3]
        with self.assertRaises(IndexError):
            obtener_elemento(datos, 5)  # Índice inválido
            
if __name__ == '__main__':
    unittest.main()            