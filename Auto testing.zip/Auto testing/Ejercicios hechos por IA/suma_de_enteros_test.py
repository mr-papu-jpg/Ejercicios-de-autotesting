import unittest
import suma_de_enteros

class TestSumaElementos(unittest.TestCase):
    def testsumatipo_invalido(self):
        with self.assertRaises(TypeError):
            sumar_elementos("texto", 5)  # str + int → TypeError
            
if __name__ == '__main__':
    unittest.main()            