def obtener_elemento(lista, indice):
    return lista[indice]