def buscar_valor(diccionario, clave):
    return diccionario[clave]