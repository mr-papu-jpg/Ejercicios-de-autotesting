def duplicar_lista(lista):
    return lista  "2"  # Error: str  list → TypeError