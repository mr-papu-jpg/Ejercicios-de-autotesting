import pandas as pd
import numpy as np
import unittest
import datas_inestables

class TestAnalizisDeDatos(unittest.TestCase):
	def test_error_analizar_datos(self):
		df=pd.DataFrame([3, 2, 4, 10, 7,67])
		
		with self.assertRaises(TypeError):
		  	
		  	resultado = analizar_datos(df)
		
		with self.assertIsInstance(TypeError):
		  	
		  	resultado = analizar_datos(df)
    	
		with self.assertIsNone(TypeError):
		  	
		  	resultado = analizar_datos(df)
    	
if __name__=='__main__':
	unittest.main()    			