import pandas as pd

def analizar_datos(df):
    promedio = df["valor"].mean()
    maximo = df["valor"].max()
    resultado = promedio / maximo
    return round(resultado, 2)