import unittest
import suma_columnas

class TestSumaColumna(unittest.TestCase):
    def test_error_tipo_suma(self):
        df = pd.DataFrame({'nombres': ['Ana', 'Luis', 'Carlos']})
        arreglo = np.array([1, 2, 3])

        with self.assertRaises(TypeError):
            # Esto debería lanzar un TypeError porque no se puede sumar str + int
            resultado = sumar_columna(df, 'nombres', arreglo)

if __name__ == '__main__':
    unittest.main()