import pytest
import numpy as np
import pandas as pd
from suma_columnas import sumar_columna

def test_suma_tipo_incompatible():
    df = pd.DataFrame({'nombres': ['Ana', 'Luis', 'Carlos']})
    arreglo = np.array([1, 2, 3])

    with pytest.raises(TypeError):
        sumar_columna(df, 'nombres', arreglo)
        
if __name__ == '__main__':
    pytest.main()        