import numpy as np
import pandas as pd

def sumar_columna(df, columna, arreglo):
    """
    Intenta sumar una columna del DataFrame con un arreglo de NumPy.
    """
    return df[columna] + arreglo